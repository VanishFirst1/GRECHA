﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class BroniAdd : Form
    {
        public BroniAdd()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += BroniAdd_FormClosing;
        }

        private void bookingsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bookingsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tyrDataSet);

        }

        private void BroniAdd_Load(object sender, EventArgs e)
        {
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.Client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.tyrDataSet.Client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.Tours". При необходимости она может быть перемещена или удалена.
            this.toursTableAdapter.Fill(this.tyrDataSet.Tours);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.Bookings". При необходимости она может быть перемещена или удалена.
            this.bookingsTableAdapter.Fill(this.tyrDataSet.Bookings);
            bindingNavigatorAddNewItem.PerformClick();
            disabilityTextBox.Text = "Нет";
            bookingDateDateTimePicker.Text = DateTime.Now.ToString();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            BroniMain main = new BroniMain();
            this.Hide();
            main.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.bookingsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.tyrDataSet);
                MessageBox.Show("Сохранено успешно!", "Сохранение");
            }catch
            {
                MessageBox.Show("Данные не верны!");
            }
            
        }

        private void BroniAdd_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
