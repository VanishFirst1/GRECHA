﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += Main_FormClosing; 
        }



        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void покупателиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClientsMain clients = new ClientsMain();
            clients.StartPosition = FormStartPosition.CenterScreen;
            clients.Show();
            this.Hide();
        }

        private void турыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TourMain tourMain = new TourMain();
            this.Hide();
            tourMain.Show();
        }

        private void брониToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BroniMain das = new BroniMain();
            this.Hide();
            das.Show();
        }

        private void покупкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PokypkiMain pk = new PokypkiMain();
            this.Hide();
            pk.Show();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void заметкиИПожеланияКлиентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Notes_And_Wishes nw = new Notes_And_Wishes();
            this.Hide();
            nw.Show();
        }

        private void страховкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Insurance ins = new Insurance();
            this.Hide();
            ins.Show();
        }

        private void услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DisableService dbs = new DisableService();
            this.Hide();
            dbs.Show();
        }

        private void сервисыДляКлиентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Service service = new Service();
            this.Hide();
            service.Show();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
