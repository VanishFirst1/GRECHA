﻿using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace grecha
{
    public partial class RegistManager : Form
    {
        private const string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

        public RegistManager()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += RegistManager_FormClosing; 
        }

        private void btnRegistManager_Click(object sender, EventArgs e)
        {
            string surname = txtSurname.Text;
            string name = txtName.Text;
            string patronymic = txtPatronymic.Text;
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            // Проверка наличия логина и пароля
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Логин и пароль обязательны для заполнения.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка наличия логина в базе данных
            if (IsLoginExists(login))
            {
                MessageBox.Show("Данный логин уже занят, выберите другой.");
                return;
            }

            // Хэширование пароля
            string hashedPassword = HashPassword(password);

            // Регистрация нового пользователя
            RegisterUser(surname, name, patronymic, login, hashedPassword);

            MessageBox.Show("Регистрация прошла успешно!");
            Main main = new Main();
            main.Show();
            this.Hide();
        }

        private bool IsLoginExists(string login)
        {
            bool result = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM [Usеr] WHERE UserLogin = @Login";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    if (count > 0)
                    {
                        result = true;
                    }
                }
            }
            return result;
        }

        private void RegisterUser(string surname, string name, string patronymic, string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [Usеr] (UserSurname, UserName, UserPatronymic, UserLogin, UserPassword, IDRole) VALUES (@Surname, @Name, @Patronymic, @Login, @Password, @IDRole)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Surname", surname);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Patronymic", patronymic);
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@IDRole", 2); // Пользовательская роль, можете изменить в соответствии с вашей логикой
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void RegistManager_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < 16; i++) // Используем первые 16 байт (32 символа)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
