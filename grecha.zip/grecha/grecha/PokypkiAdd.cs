﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class PokypkiAdd : Form
    {
        public PokypkiAdd()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += PokypkiAdd_FormClosing; 
        }

        private void clientTourBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientTourBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tyrDataSet);

        }

        private void PokypkiAdd_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.ClientTour". При необходимости она может быть перемещена или удалена.
            this.clientTourTableAdapter.Fill(this.tyrDataSet.ClientTour);
            bindingNavigatorAddNewItem.PerformClick();

        }

        private void tourIDLabel_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PokypkiMain pk = new PokypkiMain();
            this.Hide();
            pk.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                this.Validate();
                this.clientTourBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.tyrDataSet);
                MessageBox.Show("Сохранение успешно!", "Информация");
            }
            catch { MessageBox.Show("Введенные данные не верны!","Ошибка!"); }

        }

        private void PokypkiAdd_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
