﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class Notes_And_Wishes : Form
    {
        public Notes_And_Wishes()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += Notes_And_Wishes_FormClosing; 
        }
        private void NotesAndWishes_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        public void LoadData()
        {
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ClientNotesID, ClientNotes, CustomerWishes FROM NotesAndWishes";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;
                }
            }
        }
        private void DeleteRowFromDataGrid()
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                // Получаем значение ClientNotes из выбранной строки
                string clientNotes = row.Cells[2].Value.ToString();

                // Удаляем строку из DataGridView
                dataGridView1.Rows.Remove(row);

                // Удаляем запись из базы данных
                DeleteRowFromDatabase(clientNotes);
            }
        }
        private void DeleteRowFromDatabase(string clientNotes)
        {
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "DELETE FROM NotesAndWishes WHERE CustomerWishes = @CustomerWishes";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerWishes", clientNotes);
                    command.ExecuteNonQuery();
                }
            }
        }

        private void Notes_And_Wishes_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.NotesAndWishes". При необходимости она может быть перемещена или удалена.
            this.notesAndWishesTableAdapter.Fill(this.tyrDataSet.NotesAndWishes);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Main m = new Main();
            this.Hide();
            m.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteRowFromDataGrid();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            NotesAndWishesADD nawa = new NotesAndWishesADD();
            this.Hide();
            nawa.Show();
        }

        private void Notes_And_Wishes_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
