﻿namespace grecha
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.покупателиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.турыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.брониToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.покупкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заметкиИПожеланияКлиентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.страховкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сервисыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сервисыДляКлиентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.MediumPurple;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.покупателиToolStripMenuItem,
            this.турыToolStripMenuItem,
            this.брониToolStripMenuItem,
            this.покупкиToolStripMenuItem,
            this.заметкиИПожеланияКлиентовToolStripMenuItem,
            this.страховкиToolStripMenuItem,
            this.сервисыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(897, 29);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // покупателиToolStripMenuItem
            // 
            this.покупателиToolStripMenuItem.Name = "покупателиToolStripMenuItem";
            this.покупателиToolStripMenuItem.Size = new System.Drawing.Size(92, 25);
            this.покупателиToolStripMenuItem.Text = "Клиенты";
            this.покупателиToolStripMenuItem.Click += new System.EventHandler(this.покупателиToolStripMenuItem_Click);
            // 
            // турыToolStripMenuItem
            // 
            this.турыToolStripMenuItem.Name = "турыToolStripMenuItem";
            this.турыToolStripMenuItem.Size = new System.Drawing.Size(62, 25);
            this.турыToolStripMenuItem.Text = "Туры";
            this.турыToolStripMenuItem.Click += new System.EventHandler(this.турыToolStripMenuItem_Click);
            // 
            // брониToolStripMenuItem
            // 
            this.брониToolStripMenuItem.Name = "брониToolStripMenuItem";
            this.брониToolStripMenuItem.Size = new System.Drawing.Size(72, 25);
            this.брониToolStripMenuItem.Text = "Брони";
            this.брониToolStripMenuItem.Click += new System.EventHandler(this.брониToolStripMenuItem_Click);
            // 
            // покупкиToolStripMenuItem
            // 
            this.покупкиToolStripMenuItem.Name = "покупкиToolStripMenuItem";
            this.покупкиToolStripMenuItem.Size = new System.Drawing.Size(91, 25);
            this.покупкиToolStripMenuItem.Text = "Покупки";
            this.покупкиToolStripMenuItem.Click += new System.EventHandler(this.покупкиToolStripMenuItem_Click);
            // 
            // заметкиИПожеланияКлиентовToolStripMenuItem
            // 
            this.заметкиИПожеланияКлиентовToolStripMenuItem.Name = "заметкиИПожеланияКлиентовToolStripMenuItem";
            this.заметкиИПожеланияКлиентовToolStripMenuItem.Size = new System.Drawing.Size(274, 25);
            this.заметкиИПожеланияКлиентовToolStripMenuItem.Text = "Заметки и пожелания клиентов";
            this.заметкиИПожеланияКлиентовToolStripMenuItem.Click += new System.EventHandler(this.заметкиИПожеланияКлиентовToolStripMenuItem_Click);
            // 
            // страховкиToolStripMenuItem
            // 
            this.страховкиToolStripMenuItem.Name = "страховкиToolStripMenuItem";
            this.страховкиToolStripMenuItem.Size = new System.Drawing.Size(105, 25);
            this.страховкиToolStripMenuItem.Text = "Страховки";
            this.страховкиToolStripMenuItem.Click += new System.EventHandler(this.страховкиToolStripMenuItem_Click);
            // 
            // сервисыToolStripMenuItem
            // 
            this.сервисыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сервисыДляКлиентовToolStripMenuItem,
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem});
            this.сервисыToolStripMenuItem.Name = "сервисыToolStripMenuItem";
            this.сервисыToolStripMenuItem.Size = new System.Drawing.Size(162, 25);
            this.сервисыToolStripMenuItem.Text = "Сервисы и услуги";
            // 
            // сервисыДляКлиентовToolStripMenuItem
            // 
            this.сервисыДляКлиентовToolStripMenuItem.Name = "сервисыДляКлиентовToolStripMenuItem";
            this.сервисыДляКлиентовToolStripMenuItem.Size = new System.Drawing.Size(502, 26);
            this.сервисыДляКлиентовToolStripMenuItem.Text = "Сервисы для клиентов";
            this.сервисыДляКлиентовToolStripMenuItem.Click += new System.EventHandler(this.сервисыДляКлиентовToolStripMenuItem_Click);
            // 
            // услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem
            // 
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem.Name = "услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem";
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem.Size = new System.Drawing.Size(502, 26);
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem.Text = "Услуги для людей с ограниченными возможностями";
            this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem.Click += new System.EventHandler(this.услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(867, 455);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(252, 519);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Туристическое агентство \"Греча\"";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(897, 553);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.Text = "Главная страница";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem турыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem брониToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem покупкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem покупателиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заметкиИПожеланияКлиентовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem страховкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сервисыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem услугиДляЛюдейСОграниченнымиВозможностямиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сервисыДляКлиентовToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}