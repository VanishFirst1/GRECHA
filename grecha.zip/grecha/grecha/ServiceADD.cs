﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class ServiceADD : Form
    {
        public ServiceADD()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Service serv = new Service();
            this.Hide();
            serv.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            decimal price;

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите название.");
                return;
            }

            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Введите корректную цену.");
                return;
            }

            // Строка подключения к базе данных
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

            // SQL-запрос для добавления записи
            string insertQuery = "INSERT INTO Service (Name, Price) VALUES (@Name, @Price); SELECT SCOPE_IDENTITY();";

            // Подключение к базе данных и выполнение команды добавления
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Price", price);

                    // Выполнение команды и получение ID добавленной записи
                    int newID = Convert.ToInt32(command.ExecuteScalar());

                    // Добавление записи в DataGridView на форме Service
                    Service serviceForm = new Service();
                    serviceForm.AddRowToDataGridView(newID, name, price);

                    MessageBox.Show("Запись успешно добавлена.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении записи в базу данных: " + ex.Message);
                }
            }
        }
    }
}
