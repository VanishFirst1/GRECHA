﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class TourMain : Form
    {
        public TourMain()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void toursBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.toursBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tyrDataSet);

        }

        private void TourMain_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.Tours". При необходимости она может быть перемещена или удалена.
            this.toursTableAdapter.Fill(this.tyrDataSet.Tours);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Hide();
            main.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {

        }


        private void button7_Click(object sender, EventArgs e)
        {
            TourAdd tourAdd = new TourAdd();
            this.Hide();
            tourAdd.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bindingNavigatorMoveNextItem.PerformClick();
        }

        private void clientsBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            bindingNavigatorMovePreviousItem.PerformClick();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы точно хотите удалить?", "Проверка!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                bindingNavigatorDeleteItem.PerformClick();

                toursBindingNavigatorSaveItem.PerformClick();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            toursBindingNavigatorSaveItem.PerformClick();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            ClientsAdd clientsAdd = new ClientsAdd();
            this.Hide();
            clientsAdd.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.toursBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.tyrDataSet);
                MessageBox.Show("Сохранено успешно!", "Соханение успешно");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}");
            }
        }
    }
}
