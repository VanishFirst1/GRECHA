﻿using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace grecha
{
    public partial class Form1 : Form
    {
        private const string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosed += Form1_FormClosed; 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = txtLogin.Text;
            string password = txtPassword.Text;

            try
            {
                if (CheckCredentials(username, password))
                {
                    // Действия при успешной авторизации уже обрабатываются внутри CheckCredentials
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль. Попробуйте снова.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool CheckCredentials(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT UserPassword FROM [Usеr] WHERE UserLogin = @UserLogin"; // Исправлено на [Usеr]
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserLogin", username);

                connection.Open();
                string hashedPassword = (string)command.ExecuteScalar();

                if (hashedPassword != null)
                {
                    string inputHash = HashPassword(password); // Хэшируем введенный пользователем пароль

                    if (hashedPassword == inputHash)
                    {
                        // Получаем роль пользователя из базы данных
                        string roleQuery = "SELECT IDRole FROM [Usеr] WHERE UserLogin = @UserLogin"; // Исправлено на [Usеr]
                        SqlCommand roleCommand = new SqlCommand(roleQuery, connection);
                        roleCommand.Parameters.AddWithValue("@UserLogin", username);
                        int roleId = (int)roleCommand.ExecuteScalar();

                        // Проверяем роль пользователя и предоставляем соответствующий доступ
                        switch (roleId)
                        {
                            case 2:
                                // Действия для менеджера
                                MessageBox.Show("Вы авторизовались как менеджер.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                Main main = new Main();
                                main.StartPosition = FormStartPosition.CenterScreen;
                                main.Show();
                                this.Hide();
                                break;
                            case 1:
                                MessageBox.Show("Вы авторизовались как администратор.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                AdminMain adminMain = new AdminMain();
                                adminMain.StartPosition = FormStartPosition.CenterScreen;
                                adminMain.Show();
                                this.Hide();
                                break;
                        }
                        return true;
                    }
                }
                return false;
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < 16; i++) // Используем первые 16 байт (32 символа)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void btnRegist_Click(object sender, EventArgs e)
        {
            RegistManager registmanager = new RegistManager();
            registmanager.StartPosition = FormStartPosition.CenterScreen;
            registmanager.Show();
            this.Hide();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
