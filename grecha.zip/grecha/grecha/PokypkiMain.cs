﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class PokypkiMain : Form
    {
        public PokypkiMain()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += PokypkiMain_FormClosing; 
        }

        private void clientTourBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientTourBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tyrDataSet);

        }

        private void PokypkiMain_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.ClientTour". При необходимости она может быть перемещена или удалена.
            this.clientTourTableAdapter.Fill(this.tyrDataSet.ClientTour);

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            bindingNavigatorMoveNextItem.PerformClick();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bindingNavigatorMovePreviousItem.PerformClick();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы точно хотите удалить?", "Проверка!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                bindingNavigatorDeleteItem.PerformClick();
                this.Validate();
                this.clientTourBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.tyrDataSet);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            PokypkiAdd plk = new PokypkiAdd();
            this.Hide();
            plk.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.clientTourBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.tyrDataSet);
                MessageBox.Show("Сохранено успешно!", "Информация");
            }
            catch(Exception ex)
            {
                MessageBox.Show($"{ex}");
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main m = new Main();
            this.Hide();
            m.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PokypkiMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
