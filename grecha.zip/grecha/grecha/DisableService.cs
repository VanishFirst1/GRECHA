﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class DisableService : Form
    {
        public DisableService()
        {
            InitializeComponent();
            LoadData();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Hide();
            main.Show();
        }

        private void LoadData()
        {
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            string query = "SELECT ServicesForTheDisableID, IDServiceClients, Name, Price FROM ServicesForDisabled";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataGridView1.DataSource = dataTable;

                dataGridView1.Columns["ServicesForTheDisableID"].Visible = false;
                dataGridView1.Columns["IDServiceClients"].Visible = false;

                dataGridView1.Columns["Name"].HeaderText = "Название";
                dataGridView1.Columns["Price"].HeaderText = "Цена";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;
                int selectedId = Convert.ToInt32(dataGridView1.Rows[selectedIndex].Cells["ServicesForTheDisableID"].Value);

                DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
                    string deleteQuery = "DELETE FROM ServicesForDisabled WHERE ServicesForTheDisableID = @Id";

                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();
                            SqlCommand command = new SqlCommand(deleteQuery, connection);
                            command.Parameters.AddWithValue("@Id", selectedId);
                            command.ExecuteNonQuery();
                        }

                        MessageBox.Show("Запись успешно удалена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LoadData();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DisableServiceADD addForm = new DisableServiceADD();
            addForm.RecordAdded += () => LoadData();
            addForm.ShowDialog();
        }
    }
}
