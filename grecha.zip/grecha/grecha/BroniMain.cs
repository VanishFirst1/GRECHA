﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace grecha
{
    public partial class BroniMain : Form
    {
        private string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

        public BroniMain()
        {
            InitializeComponent();
            this.FormClosing += BroniMain_FormClosing;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void BroniMain_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                string query = @"
            SELECT 
                b.[BookingID] AS 'ID',  
                t.[TourName] AS 'Название тура',
                (c.[UserSurname]+' '+c.[UserName]+ ' ' + c.[UserPatronymic]) AS 'Клиент',
                t.[StartDate] AS 'Дата начала тура',  
                b.[BookingDate] AS 'Дата бронирования',  
                b.[Disability] AS 'Инвалидность'
            FROM [tyr].[dbo].[Tours] t
            JOIN [tyr].[dbo].[Bookings] b ON t.[TourID]=b.[TourID]
            JOIN [tyr].[dbo].[Client] c ON b.[ClientID]=c.[ClientID];
        ";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table;
                    dataGridView1.Columns["ID"].Visible = false;

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            BroniAdd broniAdd = new BroniAdd();
            broniAdd.FormClosed += (s, args) =>
            {
                LoadData();
                this.Show();
            };
            this.Hide();
            broniAdd.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Hide();
            main.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;
                int selectedId = Convert.ToInt32(dataGridView1.Rows[selectedIndex].Cells["ID"].Value);

                DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        string deleteQuery = "DELETE FROM [tyr].[dbo].[Bookings] WHERE [BookingID] = @BookingID";

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();
                            SqlCommand command = new SqlCommand(deleteQuery, connection);
                            command.Parameters.AddWithValue("@BookingID", selectedId);
                            command.ExecuteNonQuery();
                            connection.Close();
                        }

                        MessageBox.Show("Запись успешно удалена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении записи: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                excelApp.Workbooks.Add();
                Excel._Worksheet workSheet = (Excel.Worksheet)excelApp.ActiveSheet;

                int columnIndex = 1;
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    if (column.Name != "ID")
                    {
                        workSheet.Cells[1, columnIndex] = column.HeaderText;
                        columnIndex++;
                    }
                }

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    columnIndex = 1;
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (dataGridView1.Columns[j].Name != "ID")
                        {
                            var cellValue = dataGridView1.Rows[i].Cells[j].Value;
                            workSheet.Cells[i + 2, columnIndex] = cellValue == null ? "" : cellValue.ToString();
                            columnIndex++;
                        }
                    }
                }

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, "ExportedData.xlsx");

                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }

                workSheet.SaveAs(filePath);
                excelApp.Quit();

                System.Diagnostics.Process.Start(filePath);

                MessageBox.Show($"Данные успешно экспортированы в файл: {filePath}", "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BroniMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            try
            {
                string backupPath = @"C:\Backup\tyr_backup.bak";
                string query = $"BACKUP DATABASE tyr TO DISK = '{backupPath}'";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }

                MessageBox.Show("Резервная копия базы данных успешно создана", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании резервной копии: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
