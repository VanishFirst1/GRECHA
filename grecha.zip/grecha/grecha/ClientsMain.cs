﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class ClientsMain : Form
    {
        private SqlConnection _connection;
        private SqlDataAdapter _adapter;
        private DataTable _dataTable;

        public ClientsMain()
        {
            InitializeComponent();
            InitializeButtonClickEventHandlers();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += ClientsMain_FormClosing; 
        }
        private void InitializeButtonClickEventHandlers()
        {
            btnRefresh.Click += btnRefresh_Click;
        }
        private void ClientsMain_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            _connection = new SqlConnection(connectionString);
            _adapter = new SqlDataAdapter("SELECT * FROM Client", _connection);
            _dataTable = new DataTable();
            _adapter.Fill(_dataTable);

            dataGridView1.DataSource = _dataTable;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                try
                {
                    // Получаем значение адреса электронной почты из текущей строки DataGridView
                    string email = dataGridView1.CurrentRow.Cells[4].Value.ToString(); // 4 - это индекс столбца "Email"

                    // Удаление записи из базы данных по адресу электронной почты
                    string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(
                            "DELETE FROM Client WHERE Email = @Email",
                            connection))
                        {
                            command.Parameters.AddWithValue("@Email", email);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " запись(ей) удалено");
                        }
                    }

                    // Обновляем данные в DataGridView
                    _dataTable.Clear();
                    _adapter.Fill(_dataTable);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении записи: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.");
            }
        }


        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _connection.Dispose();
            _adapter.Dispose();
            _dataTable.Dispose();
            base.OnFormClosing(e);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClientsAdd clientsadd = new ClientsAdd();
            clientsadd.StartPosition = FormStartPosition.CenterScreen;
            clientsadd.ShowDialog(); // Открываем форму ClientsAdd модально

            // Получаем данные из формы ClientsAdd после ее закрытия
            string[] rowData = (string[])clientsadd.Tag;

            if (rowData != null)
            {
                // Добавляем данные в DataTable и обновляем DataGridView
                _dataTable.Rows.Add(rowData);
            }
        }

        private void InitializeDataGridView()
        {
            // Создаем столбцы в DataGridView
            DataGridViewTextBoxColumn columnFirstName = new DataGridViewTextBoxColumn();
            columnFirstName.HeaderText = "Имя";
            columnFirstName.DataPropertyName = "FirstName"; // Имя столбца в DataTable
            dataGridView1.Columns.Add(columnFirstName);

            // Устанавливаем источник данных для DataGridView
            dataGridView1.DataSource = _dataTable;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var main = new Main();
            main.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }
        public void RefreshDataGridView()
        {
            _dataTable.Clear();
            _adapter.Fill(_dataTable);
        }

        private void ClientsMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
