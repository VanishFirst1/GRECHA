﻿namespace grecha
{
    partial class Notes_And_Wishes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Notes_And_Wishes));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.clientNotesIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientNotesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerWishesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.notesAndWishesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tyrDataSet = new grecha.tyrDataSet();
            this.notesAndWishesTableAdapter = new grecha.tyrDataSetTableAdapters.NotesAndWishesTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notesAndWishesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clientNotesIDDataGridViewTextBoxColumn,
            this.clientNotesDataGridViewTextBoxColumn,
            this.customerWishesDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.notesAndWishesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(260, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // clientNotesIDDataGridViewTextBoxColumn
            // 
            this.clientNotesIDDataGridViewTextBoxColumn.DataPropertyName = "ClientNotesID";
            this.clientNotesIDDataGridViewTextBoxColumn.HeaderText = "ClientNotesID";
            this.clientNotesIDDataGridViewTextBoxColumn.Name = "clientNotesIDDataGridViewTextBoxColumn";
            this.clientNotesIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.clientNotesIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // clientNotesDataGridViewTextBoxColumn
            // 
            this.clientNotesDataGridViewTextBoxColumn.DataPropertyName = "ClientNotes";
            this.clientNotesDataGridViewTextBoxColumn.HeaderText = "Заметки";
            this.clientNotesDataGridViewTextBoxColumn.Name = "clientNotesDataGridViewTextBoxColumn";
            // 
            // customerWishesDataGridViewTextBoxColumn
            // 
            this.customerWishesDataGridViewTextBoxColumn.DataPropertyName = "CustomerWishes";
            this.customerWishesDataGridViewTextBoxColumn.HeaderText = "Пожелания";
            this.customerWishesDataGridViewTextBoxColumn.Name = "customerWishesDataGridViewTextBoxColumn";
            // 
            // notesAndWishesBindingSource
            // 
            this.notesAndWishesBindingSource.DataMember = "NotesAndWishes";
            this.notesAndWishesBindingSource.DataSource = this.tyrDataSet;
            // 
            // tyrDataSet
            // 
            this.tyrDataSet.DataSetName = "tyrDataSet";
            this.tyrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // notesAndWishesTableAdapter
            // 
            this.notesAndWishesTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumPurple;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 159);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(278, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 112);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Редактирование";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.MediumPurple;
            this.btnAdd.Location = new System.Drawing.Point(6, 59);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(188, 46);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Добавление";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.MediumPurple;
            this.btnDelete.Location = new System.Drawing.Point(6, 19);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(188, 34);
            this.btnDelete.TabIndex = 0;
            this.btnDelete.Text = "Удаление";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // Notes_And_Wishes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(511, 191);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Notes_And_Wishes";
            this.Text = "Заметки и пожелания клиентов";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Notes_And_Wishes_FormClosing);
            this.Load += new System.EventHandler(this.Notes_And_Wishes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notesAndWishesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tyrDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private tyrDataSet tyrDataSet;
        private System.Windows.Forms.BindingSource notesAndWishesBindingSource;
        private tyrDataSetTableAdapters.NotesAndWishesTableAdapter notesAndWishesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientNotesIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientNotesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerWishesDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
    }
}