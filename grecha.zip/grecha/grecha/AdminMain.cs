﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class AdminMain : Form
    {
        
        string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

        public AdminMain()
        {
            InitializeComponent();
            this.FormClosing += AdminMain_FormClosing; 
            LoadUserData(); 
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void AdminMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }

        private void LoadUserData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Запрос SQL с выбором нужных столбцов и переименованием
                SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT UsеrID as 'UserID', IDRole, UserSurname as 'Фамилия', UserName as 'Имя', UserPatronymic as 'Отчество', UserLogin as 'Логин', UserPassword as 'Пароль' FROM [Usеr]", connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                
                dataGridView1.DataSource = dataTable;

               
                if (dataGridView1.Columns["UserID"] != null)
                    dataGridView1.Columns["UserID"].Visible = false;
            }
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            this.Hide();
            fr1.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int userID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["UserID"].Value);

                // Удаляем связанные записи из таблицы Tours
                string deleteToursQuery = "DELETE FROM Tours WHERE IDUser = @UserID";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(deleteToursQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        command.ExecuteNonQuery();
                    }
                }

                // Удаляем запись из таблицы Usеr
                string deleteUsеrQuery = "DELETE FROM Usеr WHERE UsеrID = @UserID";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(deleteUsеrQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", userID);
                        command.ExecuteNonQuery();
                    }
                }
                LoadUserData();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
