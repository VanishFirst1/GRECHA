﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class TourAdd : Form
    {
        public TourAdd()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += TourAdd_FormClosing; 
        }

        private void toursBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.toursBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.tyrDataSet);

        }

        private void TourAdd_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "tyrDataSet.Tours". При необходимости она может быть перемещена или удалена.
            this.toursTableAdapter.Fill(this.tyrDataSet.Tours);
            bindingNavigatorAddNewItem.PerformClick();

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                toursBindingNavigatorSaveItem.PerformClick();
                MessageBox.Show("Сохранено успешно!","Соханение успешно");
                TourMain tourMain = new TourMain();
                this.Hide();
                tourMain.ShowDialog();
            }
            catch
            {
                MessageBox.Show("Введенные данные не верны!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TourMain tourMain = new TourMain();
            this.Hide();
            tourMain.ShowDialog();
        }

        private void TourAdd_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}
