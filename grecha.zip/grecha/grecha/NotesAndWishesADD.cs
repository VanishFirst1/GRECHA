﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class NotesAndWishesADD : Form
    {
        public NotesAndWishesADD()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormClosing += NotesAndWishesADD_FormClosing; 
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Notes_And_Wishes noteswishes = new Notes_And_Wishes();
            this.Hide();
            noteswishes.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string clientNotes = txtNotes.Text;
            string customerWishes = txtWishes.Text;

            if (string.IsNullOrEmpty(clientNotes) || string.IsNullOrEmpty(customerWishes))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO NotesAndWishes (ClientNotes, CustomerWishes) VALUES (@ClientNotes, @CustomerWishes)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ClientNotes", clientNotes);
                    command.Parameters.AddWithValue("@CustomerWishes", customerWishes);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            MessageBox.Show("Запись успешно добавлена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtNotes.Clear();
            txtWishes.Clear();

            if (this.Owner is Notes_And_Wishes notesAndWishesForm)
            {
                notesAndWishesForm.LoadData();
            }
        }

        private void NotesAndWishesADD_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }
    }
}