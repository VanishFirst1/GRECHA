﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class Insurance : Form
    {
        public Insurance()
        {
            InitializeComponent();
            LoadData();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void LoadData()
        {
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

            // Запрос SQL для выборки данных из таблицы Insurance
            string query = "SELECT InsuranceID, IDServiceClients, Name, ExactPrice FROM Insurance";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Установка источника данных для DataGridView
                dataGridView1.DataSource = dataTable;

                // Скрытие столбцов InsuranceID и IDServiceClients
                dataGridView1.Columns["InsuranceID"].Visible = false;
                dataGridView1.Columns["IDServiceClients"].Visible = false;

                // Переименование заголовков столбцов
                dataGridView1.Columns["Name"].HeaderText = "Наименование страховки";
                dataGridView1.Columns["ExactPrice"].HeaderText = "Цена";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Проверка на выбор строки
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int insuranceID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["InsuranceID"].Value);

                string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
                string deleteQuery = "DELETE FROM Insurance WHERE InsuranceID = @InsuranceID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        // Создание команды
                        SqlCommand command = new SqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@InsuranceID", insuranceID);
                        command.ExecuteNonQuery();

                        // Обновление данных в DataGridView
                        LoadData();
                        MessageBox.Show("Запись успешно удалена.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении записи: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку для удаления.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.Show();
            this.Close();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            InsuranceADD insADD = new InsuranceADD(this); // Передаем текущую форму в конструктор
            insADD.Show();
            this.Hide();
        }

        public void ShowAgain()
        {
            LoadData(); // Обновляем данные при возврате
            this.Show();
        }
    }
}
