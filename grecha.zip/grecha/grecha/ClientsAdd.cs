﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grecha
{
    public partial class ClientsAdd : Form
    {
        private string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
        public ClientsAdd()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ClientsMain main = new ClientsMain();
            this.Hide();
            main.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Собираем данные
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string middleName = txtMiddleName.Text;
            string email = txtEmail.Text;
            string phoneNumber = txtPhoneNumber.Text;
            DateTime dateOfBirth = dateTimePicker1.Value;

            // Создаем запрос SQL для вставки данных без упоминания столбца ClientID
            string query = "INSERT INTO Client (UserSurname, UserName, UserPatronymic, Email, PhoneNumber, DateOfBirth) VALUES (@UserSurname, @UserName, @UserPatronymic, @Email, @PhoneNumber, @DateOfBirth)";

            // Создаем подключение и команду для выполнения запроса
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавляем параметры к запросу
                    command.Parameters.AddWithValue("@UserSurname", lastName);
                    command.Parameters.AddWithValue("@UserName", firstName);
                    command.Parameters.AddWithValue("@UserPatronymic", middleName);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    command.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);

                    connection.Open();
                    command.ExecuteNonQuery();
                    
                }
                this.Close();
            }
        }
    }
}
