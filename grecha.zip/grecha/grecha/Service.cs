﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class Service : Form
    {
        public Service()
        {
            InitializeComponent();
            this.Load += new EventHandler(Service_Load);
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Service_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            // Строка подключения к вашей базе данных
            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

            // SQL-запрос для получения данных
            string query = "SELECT ServiceClientsID, Name, Price FROM Service";

            // Создание DataTable для хранения данных
            DataTable dataTable = new DataTable();

            // Подключение к базе данных и заполнение DataTable
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataTable);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message);
                }
            }

            // Установка DataTable как источника данных для DataGridView
            dataGridView1.DataSource = dataTable;

            // Скрытие столбца ServiceClientsID
            if (dataGridView1.Columns["ServiceClientsID"] != null)
            {
                dataGridView1.Columns["ServiceClientsID"].Visible = false;
            }

            // Изменение заголовков столбцов Name и Price
            if (dataGridView1.Columns["Name"] != null)
            {
                dataGridView1.Columns["Name"].HeaderText = "Название";
            }

            if (dataGridView1.Columns["Price"] != null)
            {
                dataGridView1.Columns["Price"].HeaderText = "Цена";
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Hide();
            main.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получение ServiceClientsID выбранной строки
                int serviceClientsID = (int)dataGridView1.SelectedRows[0].Cells["ServiceClientsID"].Value;

                // Строка подключения к базе данных
                string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";

                // SQL-запрос для удаления записи
                string deleteQuery = "DELETE FROM Service WHERE ServiceClientsID = @ServiceClientsID";

                // Подключение к базе данных и выполнение команды удаления
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@ServiceClientsID", serviceClientsID);
                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении записи из базы данных: " + ex.Message);
                        return;
                    }
                }

                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.");
            }
        }

        public void AddRowToDataGridView(int serviceClientsID, string name, decimal price)
        {
            DataTable dataTable = dataGridView1.DataSource as DataTable;
            if (dataTable != null)
            {
                DataRow row = dataTable.NewRow();
                row["ServiceClientsID"] = serviceClientsID;
                row["Name"] = name;
                row["Price"] = price;
                dataTable.Rows.Add(row);
            }
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            ServiceADD serviceADD = new ServiceADD();
            this.Hide();
            serviceADD.Show();
        }
    }
}