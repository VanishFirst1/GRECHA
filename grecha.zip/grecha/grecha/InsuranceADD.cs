﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace grecha
{
    public partial class InsuranceADD : Form
    {
        private Insurance parentForm;

        public InsuranceADD(Insurance parent)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            parentForm = parent;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string name = txtName.Text;
            decimal price;

            if (string.IsNullOrEmpty(name) || !decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Пожалуйста, введите корректные данные.");
                return;
            }

            string connectionString = "Data Source=DESKTOP-R934923\\SQLEXPRESS;Initial Catalog=tyr;Integrated Security=True";
            string insertQuery = "INSERT INTO Insurance (Name, ExactPrice) VALUES (@Name, @ExactPrice)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Создание команды
                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@ExactPrice", price);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Запись успешно добавлена.");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении записи: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            parentForm.ShowAgain(); // Показываем родительскую форму
        }
    }
}
